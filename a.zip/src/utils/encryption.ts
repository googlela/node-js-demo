const crypto = require("crypto");
const secrate = "tushar2197";
const { publicKey, privateKey } = crypto.generateKeyPairSync("rsa", {
    // The standard secure default length for RSA keys is 2048 bits
    modulusLength: 2048,
});

const verifiableData = "this need to be verified"
const signature = crypto.sign("sha256", Buffer.from(verifiableData), {
    key: privateKey,
    padding: crypto.constants.RSA_PKCS1_PSS_PADDING,
})

const isVerified = crypto.verify(
    "sha256",
    Buffer.from(verifiableData),
    {
        key: publicKey,
        padding: crypto.constants.RSA_PKCS1_PSS_PADDING,
    },
    signature
)

export class Encryption {

    public async encrypt(data: any) {
       
        const encryptedData = crypto.publicEncrypt(
            {
                key: publicKey,
                padding: crypto.constants.RSA_PKCS1_OAEP_PADDING,
                oaepHash: "sha256",
            },
            // We convert the data string to a buffer using `Buffer.from`
            Buffer.from(data)
        )
       
        console.log("encypted data: ", encryptedData.toString("base64"))
        return encryptedData.toString("base64")
    }



    public async decrypt(data: any) {

      
        const decryptedData =await  crypto.privateDecrypt(
            {
                key: privateKey,
                // In order to decrypt the data, we need to specify the
                // same hashing function and padding scheme that we used to
                // encrypt the data in the previous step
                padding: crypto.constants.RSA_PKCS1_OAEP_PADDING,
                oaepHash: "sha256",
            },
            Buffer.from(data)
        )
        console.log("decrypted data: ", decryptedData.toString())
        return decryptedData.toString()
    }
   


}