import mongoose from "mongoose";
// MongoDb Configurations
const options = {
    useNewUrlParser: true,
    useFindAndModify: false,
    useUnifiedTopology: true,
    useCreateIndex: true
};



const DB_URI = `mongodb+srv://tushar:Papa@1527@cluster0.kvqys.mongodb.net/socket`;
export const connect = async () => {
    mongoose.connect(DB_URI, options).then((client) => {
        console.log('DB is connected.')
    });
};

