import express, { json } from 'express';
import { UserRouter } from './user/user.routes';
import { connect } from './config/db'


const app = express();
const port = 4001;
app.use(json())
app.use('/api/user', new UserRouter().router)
app.listen(port)
connect().catch(error => console.log(error));
console.log(`server is listening on ${port}`);
